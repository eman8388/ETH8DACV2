#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <SystemConfiguration/SystemConfiguration.h>
#include <CoreFoundation/CoreFoundation.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <ifaddrs.h>
#include <net/if.h>
#include <net/if_dl.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <net/bpf.h>
#include <errno.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/event.h>
#include <sys/time.h>
#include <atomic>

#include <dispatch/dispatch.h>

#define INTERFACE_REFRESH_VIEW (double)0.1
#define ETHLINK_ETH_TYPE 0x0802
#define DEVICE_FRAME_PER_BUFFER 8

#define SND_PACKET_SIZE (64+(DEVICE_FRAME_PER_BUFFER*32))
#define RCV_PACKET_SIZE 64

#define QUEUE_MULTIPLIER 2

typedef struct {
    int write_index;
    int read_index;
    uint32_t queue_size;
    uint8_t **buffer_queue; // Allocazione dinamica
    dispatch_semaphore_t sem_free_slots;
    dispatch_semaphore_t sem_used_slots;
    dispatch_queue_t queue;
} QUEUE;

typedef struct{
    int bpf_fd;
    int bpf_fd_S;
    uint8_t send_packet[64];
    int internal_queue;
    int packet_delay;
    int error_counter;
    int64_t output_timing;
    uint16_t SN;
    QUEUE input_queue;
    QUEUE output_queue;
    dispatch_source_t input_bpf_source;
    bool stop_send_thread;
}ETHlink;

int open_bpf( char *ifname);
void get_interface_information(char *interface_name, char *interface_friendly_name, uint8_t *mac_address);

ETHlink* ETHlink_start(int interface_index,uint16_t device_serial_number,int queue_lenght,int delay,double sample_rate);
ETHlink* ETHlink_stop(ETHlink *ethlink);

int ETHlink_send(ETHlink *ethlink,int32_t* buffer_data);
int ETHlink_receive(ETHlink *ethlink,uint8_t* buffer_data);


