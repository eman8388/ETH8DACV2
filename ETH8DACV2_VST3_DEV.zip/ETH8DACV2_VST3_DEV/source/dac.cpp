#include "dac.h"

//!!!!!!!!!!!!!!!!!!!!!MAX WIN !!!!!!!!!!!!!!!!!!

// Funzione per ottenere informazioni sull'interfaccia
void get_interface_information(char *interface_name, char *interface_friendly_name, uint8_t *mac_address) {
    // Inizializza il friendly name come vuoto
    strcpy(interface_friendly_name, "Unknown");

    // Ottieni il friendly name usando SystemConfiguration
    SCPreferencesRef prefs = SCPreferencesCreate(NULL, CFSTR("com.example.networkinfo"), NULL);
    CFArrayRef interfaces = SCNetworkInterfaceCopyAll();

    for (CFIndex i = 0; i < CFArrayGetCount(interfaces); i++) {
        SCNetworkInterfaceRef interface = (SCNetworkInterfaceRef)CFArrayGetValueAtIndex(interfaces, i);
        CFStringRef bsd_name = SCNetworkInterfaceGetBSDName(interface);
        CFStringRef friendly_name = SCNetworkInterfaceGetLocalizedDisplayName(interface);

        if (bsd_name && friendly_name) {
            char bsd[256], friendly[256];
            CFStringGetCString(bsd_name, bsd, sizeof(bsd), kCFStringEncodingUTF8);
            CFStringGetCString(friendly_name, friendly, sizeof(friendly), kCFStringEncodingUTF8);

            if (strcmp(bsd, interface_name) == 0) {
                strcpy(interface_friendly_name, friendly);
                break;
            }
        }
    }

    CFRelease(interfaces);
    CFRelease(prefs);

    // Ottieni l'indirizzo MAC usando getifaddrs
    struct ifaddrs *ifaddr, *ifa;

    if (getifaddrs(&ifaddr) == -1) {
        perror("getifaddrs");
        return;
    }

    for (ifa = ifaddr; ifa != NULL; ifa = ifa->ifa_next) {
        if (ifa->ifa_addr == NULL)
            continue;

        // Cerca un'interfaccia di tipo AF_LINK (link-layer)
        if (strcmp(ifa->ifa_name, interface_name) == 0 && ifa->ifa_addr->sa_family == AF_LINK) {
            struct sockaddr_dl *sdl = (struct sockaddr_dl *)ifa->ifa_addr;

            // Copia l'indirizzo MAC
            memcpy(mac_address, LLADDR(sdl), 6);
            break;
        }
    }

    freeifaddrs(ifaddr);
}

// Function to get interface name by index (max 10 interface)
int get_name_by_index(int interface_index, char* interface_name ) {
    if(interface_index>10 || interface_index<0){
        printf("invalid interface index !\n");
        return 0;
    }
    // Ottieni l'indirizzo MAC usando getifaddrs
    struct ifaddrs *ifaddr, *ifa;
    int i=0;
    if (getifaddrs(&ifaddr) == -1) {
        perror("getifaddrs");
        return 0;
    }
    
    for (ifa = ifaddr; ifa != NULL; ifa = ifa->ifa_next) {
        if (ifa->ifa_addr == NULL)
            continue;

        if (ifa->ifa_name && (strncmp(ifa->ifa_name, "en", 2) == 0) && ifa->ifa_addr->sa_family == AF_LINK ) {
            if(i==interface_index){
                break;
            }
            i++;
        }
    }

    if(ifa==NULL){
        printf("no interface found at index %d !\n",interface_index);
        freeifaddrs(ifaddr);
        return 0;
    }
    
    strcpy(interface_name,ifa->ifa_name);

    freeifaddrs(ifaddr);
    
    return 1;
}

int open_bpf( char *ifname,u_int buffer_size) {
    int fd = -1;
    char devname[16];

    // Scorri i dispositivi BPF finché non ne trovi uno disponibile
    for (int i = 0; i < 256; i++) {
        snprintf(devname, sizeof(devname), "/dev/bpf%d", i);
        fd = open(devname, O_RDWR | O_NONBLOCK );
        if (fd >=0) {
            printf("Utilizzo del dispositivo: %s\n", devname);
            break;
        }
    }
    if (fd == -1) {
        perror("Nessun dispositivo BPF disponibile");
        return -1;
    }

    if (ioctl(fd, BIOCSBLEN, &buffer_size) < 0) {
        perror("Errore in BIOCSBLEN (BUFFERSIZE SET)");
        close(fd);
        return -1;
    }
    printf("Buffer BPF impostato a  %u byte\n", buffer_size);
    
    // Imposta la modalità immediate (i pacchetti saranno resi disponibili appena arrivano)
    u_int immediate = 1;
    if (ioctl(fd, BIOCIMMEDIATE, &immediate) < 0) {
        perror("Errore in ioctl(BIOCIMMEDIATE)");
        close(fd);
        return -1;
    }
    printf("Modalità immediate abilitata.\n");
    
    // Associa il dispositivo BPF all'interfaccia specificata
    struct ifreq ifr;
    strncpy(ifr.ifr_name, ifname, sizeof(ifr.ifr_name) - 1);
    ifr.ifr_name[sizeof(ifr.ifr_name) - 1] = '\0';
    if (ioctl(fd, BIOCSETIF, &ifr) < 0) {
        perror("Errore in ioctl(BIOCSETIF)");
        close(fd);
        return -1;
    }
    printf("Associato il dispositivo BPF all'interfaccia %s\n", ifname);
    
    return fd;
}

int apply_bpf_filter_manual(int bpf_fd, const uint8_t device_mac[6]) {
    // Definizione dell'array con valori placeholder per i campi 'k' dipendenti da device_mac
    struct bpf_insn filter[10] = {
        /* 0: Carica EtherType (offset 12) */
        { BPF_LD  | BPF_H | BPF_ABS, 0, 0, 12 },
        /* 1: Se EtherType != 0x0802, salta 7 istruzioni */
        { BPF_JMP | BPF_JEQ | BPF_K, 0, 7, ETHLINK_ETH_TYPE },
        /* 2: Carica i primi 2 byte del MAC sorgente (offset 6) */
        { BPF_LD  | BPF_H | BPF_ABS, 0, 0, 6 },
        /* 3: Se MAC[0..1] != device_mac[0..1], salta 5 istruzioni */
        { BPF_JMP | BPF_JEQ | BPF_K, 0, 5, 0 },  // Assegneremo qui il valore corretto
        /* 4: Carica i successivi 2 byte del MAC sorgente (offset 8) */
        { BPF_LD  | BPF_H | BPF_ABS, 0, 0, 8 },
        /* 5: Se MAC[2..3] != device_mac[2..3], salta 3 istruzioni */
        { BPF_JMP | BPF_JEQ | BPF_K, 0, 3, 0 },  // Assegneremo qui il valore corretto
        /* 6: Carica gli ultimi 2 byte del MAC sorgente (offset 10) */
        { BPF_LD  | BPF_H | BPF_ABS, 0, 0, 10 },
        /* 7: Se MAC[4..5] != device_mac[4..5], salta 1 istruzione */
        { BPF_JMP | BPF_JEQ | BPF_K, 0, 1, 0 },  // Assegneremo qui il valore corretto
        /* 8: Accetta il pacchetto */
        { BPF_RET | BPF_K, 0, 0, 0xFFFFFFFFU },   // Usa literal unsigned
        /* 9: Rifiuta il pacchetto */
        { BPF_RET | BPF_K, 0, 0, 0 },
    };

    // Calcola e assegna i valori 'k' basati su device_mac
    filter[3].k = ((uint16_t)device_mac[0] << 8) | device_mac[1];
    filter[5].k = ((uint16_t)device_mac[2] << 8) | device_mac[3];
    filter[7].k = ((uint16_t)device_mac[4] << 8) | device_mac[5];

    struct bpf_program prog;
    prog.bf_len   = sizeof(filter) / sizeof(filter[0]);
    prog.bf_insns = filter;

    if (ioctl(bpf_fd, BIOCSETF, &prog) < 0) {
        perror("ioctl(BIOCSETF)");
        return -1;
    }

    printf("Filter for receive: ether src %02x:%02x:%02x:%02x:%02x:%02x and ether[12:2] == 0x%04x \n",
           device_mac[0], device_mac[1], device_mac[2],
           device_mac[3], device_mac[4], device_mac[5],
           ETHLINK_ETH_TYPE );
    
    return 1;
}

// Inizializza la coda con allocazione dinamica
int init_queue(QUEUE *q, uint32_t QUEUE_SIZE,int packet_lenght) {
    if (QUEUE_SIZE == 0) return 0; // Errore: dimensione non valida

    q->queue_size = QUEUE_SIZE;
    q->write_index = 0;
    q->read_index = 0;

    // Allocazione dinamica dell'array di puntatori
    q->buffer_queue = (uint8_t**)malloc(QUEUE_SIZE * sizeof(uint8_t *));
    if (!q->buffer_queue) return 0; // Errore di allocazione

    // Allocazione dei buffer per i pacchetti
    for (uint32_t i = 0; i < QUEUE_SIZE; i++) {
        q->buffer_queue[i] = (uint8_t*)malloc(packet_lenght);
        if (!q->buffer_queue[i]){
            return 0; // Errore di allocazione
        }
    }

    // Inizializza i semafori e la coda seriale
    q->sem_free_slots = dispatch_semaphore_create(QUEUE_SIZE);
    q->sem_used_slots = dispatch_semaphore_create(0);
    q->queue = dispatch_queue_create("queue_dispatch", DISPATCH_QUEUE_SERIAL);

    if (!q->sem_free_slots || !q->sem_used_slots || !q->queue) {
            fprintf(stderr, "Errore: i semafori o la dispatch queue non sono stati inizializzati correttamente\n");
            return 0;
        }

        printf("Queue inizializzata: sem_free_slots=%p, sem_used_slots=%p, queue=%p\n",
               q->sem_free_slots, q->sem_used_slots, q->queue);
    
    return 1; // Successo
}

// Inserisce un elemento nella coda
int queue_push(QUEUE *q, uint8_t *data,int packet_lenght) {
    if (dispatch_semaphore_wait(q->sem_free_slots, DISPATCH_TIME_NOW) != 0) {
        return 0; // Coda piena
    }

    dispatch_sync(q->queue, ^{
        int index = q->write_index % q->queue_size;
        memcpy(q->buffer_queue[index], data, packet_lenght);
        q->write_index++;
    });

    dispatch_semaphore_signal(q->sem_used_slots);
    return 1;
}

// Estrae un elemento dalla coda
int queue_pop(QUEUE *q, uint8_t *out,int packet_lenght) {
    if (dispatch_semaphore_wait(q->sem_used_slots, DISPATCH_TIME_NOW) != 0) {
        return 0; // Coda vuota
    }

    dispatch_sync(q->queue, ^{
        int index = q->read_index % q->queue_size;
        memcpy(out, q->buffer_queue[index],packet_lenght);
        q->read_index++;
    });

    dispatch_semaphore_signal(q->sem_free_slots);
    return 1;
}

// Libera la memoria allocata per la coda
void free_queue(QUEUE *q) {
    if (q->buffer_queue) {
        for (uint32_t i = 0; i < q->queue_size; i++) {
            free(q->buffer_queue[i]);
        }
        free(q->buffer_queue);
    }
    q->buffer_queue = NULL;
}


// Configura il dispatch source per leggere dal BPF
void setup_bpf_dispatch_source(ETHlink *ethlink) {
    char queueLabel[64];
    snprintf(queueLabel, sizeof(queueLabel), "com.ETH8DAC.bpfReadQueue_DEVICE_SN=%d", ethlink->SN);
  
    // Crea una coda dedicata per gli eventi di lettura
    dispatch_queue_t readQueue = dispatch_queue_create(queueLabel, NULL);

    ethlink->input_bpf_source = dispatch_source_create(DISPATCH_SOURCE_TYPE_READ,
                                                 ethlink->bpf_fd,
                                                 0,
                                                 readQueue);
    if (!ethlink->input_bpf_source) {
        fprintf(stderr, "Errore nella creazione del dispatch source per il BPF\n");
        return;
    }

    dispatch_source_set_event_handler(ethlink->input_bpf_source, ^{
        // Ottiene il numero di byte disponibili (anche se non usato direttamente)
        size_t available = dispatch_source_get_data(ethlink->input_bpf_source);
        if (available == 0) return;

        // Alloca un buffer per leggere i dati
        uint8_t *buffer = (uint8_t*)malloc(RCV_PACKET_SIZE * ethlink->internal_queue * QUEUE_MULTIPLIER);
        if (!buffer) {
            fprintf(stderr, "Allocazione del buffer fallita\n");
            return;
        }

        ssize_t n = read(ethlink->bpf_fd, buffer,
                         RCV_PACKET_SIZE * ethlink->internal_queue * QUEUE_MULTIPLIER);
        if (n <= 0) {
            perror("Errore in read()");
            free(buffer);
            return;
        }

        // Parsing dei pacchetti letti
        uint8_t *ptr = buffer;
        uint8_t *end = buffer + n;
        while (ptr < end) {
            struct bpf_hdr *hdr = (struct bpf_hdr *)ptr;
            if ((uint8_t *)hdr + sizeof(struct bpf_hdr) > end) {
                fprintf(stderr, "Header incompleto, interrompo parsing.\n");
                break;
            }
            uint8_t *packet_data = ptr + hdr->bh_hdrlen;
            if (packet_data + hdr->bh_caplen > end) {
                fprintf(stderr, "Pacchetto incompleto, interrompo parsing.\n");
                break;
            }
            // Inserisce il pacchetto nella coda, saltando i primi 64 byte
            queue_push(&ethlink->input_queue, packet_data,RCV_PACKET_SIZE);

            // Avanza al pacchetto successivo considerando l'allineamento
            ptr += BPF_WORDALIGN(hdr->bh_hdrlen + hdr->bh_caplen);
        }
        free(buffer);
    });

    dispatch_source_set_cancel_handler(ethlink->input_bpf_source, ^{
        free_queue(&ethlink->input_queue);
        if (close(ethlink->bpf_fd) < 0) {
            perror("error closing bpf\n");
        } else {
            printf("bpf closed correctly\n");
        }
        printf("Thread di input terminato.\n");
    });

    dispatch_resume(ethlink->input_bpf_source);
}


int ETHlink_receive(ETHlink *ethlink,uint8_t* buffer_data){
    if(!ethlink){
        return 0;
    }
    return queue_pop(&ethlink->input_queue, buffer_data,RCV_PACKET_SIZE);
}


int ETHlink_send(ETHlink *ethlink,int32_t* buffer_data){
    if(!ethlink){
        return 0;
    }
    int total_packet=0;
    static uint8_t buffer_send[SND_PACKET_SIZE]={0};
    memcpy(buffer_send,ethlink->send_packet,64);
    for(int i=0;i<ethlink->internal_queue;i++){
        memcpy(buffer_send+64,(uint8_t*)buffer_data+(i*(SND_PACKET_SIZE-64)),SND_PACKET_SIZE-64);
        if(write(ethlink->bpf_fd_S, buffer_send, SND_PACKET_SIZE)){
            total_packet++;
        }else{
            ethlink->error_counter++;
            printf("error sending %d\n",ethlink->error_counter);
        }
    }
    return total_packet;
}

ETHlink* ETHlink_start(int interface_index,uint16_t device_serial_number,int queue_lenght,int delay,double sample_rate){
    ETHlink* ethlink=(ETHlink*)malloc(sizeof(ETHlink));
    if(!ethlink){
        printf("failde to allocate memory for ethlink structure !\n");
        return NULL;
    }
    
    
    ethlink->output_timing=(NSEC_PER_SEC*((double)DEVICE_FRAME_PER_BUFFER/sample_rate))/2;
    
    char friendly_name[256];
    char interface_name[255] = { 0 };
    uint8_t interface_mac[6] = { 0 };
    uint8_t device_mac[6] = { 0X00,0XE8,0XDA,0XC0,0X00,0X00 };
    uint16_t eth_sn=ntohs(device_serial_number);
    memcpy(device_mac + 4, &eth_sn, 2);
    
    if (!get_name_by_index(interface_index, interface_name)) {
        return NULL;
    }
    
    get_interface_information(interface_name,friendly_name,interface_mac);

    printf("interface name: %s\n",interface_name);
    printf("interface friendly name: %s\n",friendly_name);
    printf("interface MAC Address: %02X:%02X:%02X:%02X:%02X:%02X\n",
           interface_mac[0], interface_mac[1], interface_mac[2],
           interface_mac[3], interface_mac[4], interface_mac[5]);
    printf("device serial number: %d\n",device_serial_number);
    printf("device MAC Address: %02X:%02X:%02X:%02X:%02X:%02X\n",
           device_mac[0], device_mac[1], device_mac[2],
           device_mac[3], device_mac[4], device_mac[5]);
    
    ethlink->internal_queue=queue_lenght;
    printf("internal queue: %d\n",ethlink->internal_queue);
    
    ethlink->bpf_fd = open_bpf(interface_name,(RCV_PACKET_SIZE*ethlink->internal_queue*QUEUE_MULTIPLIER));
    if(ethlink->bpf_fd<0){
        free(ethlink);
        printf("general error open bpf!\n");
        return NULL;
    }
    
    ethlink->bpf_fd_S = open_bpf(interface_name,SND_PACKET_SIZE*ethlink->internal_queue);
    if(ethlink->bpf_fd_S<0){
        close(ethlink->bpf_fd);
        free(ethlink);
        printf("general error open bpf_S!\n");
        return NULL;
    }
    
    init_queue(&ethlink->input_queue,delay,RCV_PACKET_SIZE);
    printf("input queue delay %d\n",delay);
    
    memcpy(ethlink->send_packet, device_mac, 6);
    memcpy(ethlink->send_packet + 6, interface_mac, 6);
    uint16_t EtherType = ntohs(ETHLINK_ETH_TYPE); //specific type
    memcpy(ethlink->send_packet + 12, &EtherType, 2);
    strncpy((char*)ethlink->send_packet + 14, "ETH8DAC", 7);
    memset(ethlink->send_packet + 21, 0, sizeof(ethlink->send_packet)-21); //!!!!!!!!!!!!!!!!!!!!! cazzo
    
    //Configura il filtro per il bpf
    apply_bpf_filter_manual(ethlink->bpf_fd,device_mac);

    // Configura il dispatch source per la lettura dal BPF
    setup_bpf_dispatch_source(ethlink);
    
    ethlink->error_counter=0;
    return ethlink;
}

ETHlink* ETHlink_stop(ETHlink* ethlink){
    if(ethlink != NULL){
        
        if(ethlink->input_bpf_source){
            dispatch_source_cancel(ethlink->input_bpf_source);
            ethlink->input_bpf_source = NULL;
        }
        if (close(ethlink->bpf_fd_S) < 0) {
            perror("error closing bpf_S\n");
        } else {
            printf("bpf_S closed correctly\n");
        }
        free(ethlink);
        
    }
    printf("ethlink closed!\n");
    return NULL;
}
