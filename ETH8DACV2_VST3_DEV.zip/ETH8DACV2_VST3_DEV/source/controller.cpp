//------------------------------------------------------------------------
// Copyright(c) 2025 eugeniomancini.
//------------------------------------------------------------------------

#include "controller.h"
#include "cids.h"
#include "vstgui/plugin-bindings/vst3editor.h"
#include "base/source/fstreamer.h"
#include "params.h"
#include "dac.h"
#include <string>
#include <locale>
#include <codecvt>
#include <stdio.h>
using namespace Steinberg;

namespace MyCompanyName {

// Supponendo che ConvertToUTF16 sia qualcosa come:
std::u16string ConvertToUTF16(const char* source) {
    std::wstring_convert<std::codecvt_utf8_utf16<char16_t>, char16_t> converter;
    return converter.from_bytes(source);
}
//------------------------------------------------------------------------
// ETH8DACV2Controller Implementation
//------------------------------------------------------------------------
tresult PLUGIN_API ETH8DACV2Controller::initialize (FUnknown* context)
{
	// Here the Plug-in will be instantiated

	//---do not forget to call parent ------
	tresult result = EditControllerEx1::initialize (context);
	if (result != kResultOk)
	{
		return result;
	}

    // Here you could register some parameters
    Vst::Parameter* param;
    setKnobMode(Vst::kLinearMode);
    parameters.addParameter(STR16("Bypass"), STR16("status"), 1, 0, Vst::ParameterInfo::kIsBypass, kBypass);
    parameters.addParameter(STR16("Connect"), STR16("status"), 1, 0, Vst::ParameterInfo::kCanAutomate, kc);

    param = new Vst::RangeParameter(STR16("Serial Number"), ksn, STR16("value"), 0, 65535, 0, 65535, Vst::ParameterInfo::kCanAutomate);
    parameters.addParameter(param);

    param = new Vst::RangeParameter(STR16("Gain Channel 1"), kg1, STR16("dB"), -56, 24, 0, 80, Vst::ParameterInfo::kCanAutomate);
    parameters.addParameter(param);
    param = new Vst::RangeParameter(STR16("Gain Channel 2"), kg2, STR16("dB"), -56, 24, 0, 80, Vst::ParameterInfo::kCanAutomate);
    parameters.addParameter(param);
    param = new Vst::RangeParameter(STR16("Gain Channel 3"), kg3, STR16("dB"), -56, 24, 0, 80, Vst::ParameterInfo::kCanAutomate);
    parameters.addParameter(param);
    param = new Vst::RangeParameter(STR16("Gain Channel 4"), kg4, STR16("dB"), -56, 24, 0, 80, Vst::ParameterInfo::kCanAutomate);
    parameters.addParameter(param);
    param = new Vst::RangeParameter(STR16("Gain Channel 5"), kg5, STR16("dB"), -56, 24, 0, 80, Vst::ParameterInfo::kCanAutomate);
    parameters.addParameter(param);
    param = new Vst::RangeParameter(STR16("Gain Channel 6"), kg6, STR16("dB"), -56, 24, 0, 80, Vst::ParameterInfo::kCanAutomate);
    parameters.addParameter(param);
    param = new Vst::RangeParameter(STR16("Gain Channel 7"), kg7, STR16("dB"), -56, 24, 0, 80, Vst::ParameterInfo::kCanAutomate);
    parameters.addParameter(param);
    param = new Vst::RangeParameter(STR16("Gain Channel 8"), kg8, STR16("dB"), -56, 24, 0, 80, Vst::ParameterInfo::kCanAutomate);
    parameters.addParameter(param);

    parameters.addParameter(STR16("Mute Chnnel 1"), STR16("status"), 1, 0, Vst::ParameterInfo::kCanAutomate, km1);
    parameters.addParameter(STR16("Mute Chnnel 2"), STR16("status"), 1, 0, Vst::ParameterInfo::kCanAutomate, km2);
    parameters.addParameter(STR16("Mute Chnnel 3"), STR16("status"), 1, 0, Vst::ParameterInfo::kCanAutomate, km3);
    parameters.addParameter(STR16("Mute Chnnel 4"), STR16("status"), 1, 0, Vst::ParameterInfo::kCanAutomate, km4);
    parameters.addParameter(STR16("Mute Chnnel 5"), STR16("status"), 1, 0, Vst::ParameterInfo::kCanAutomate, km5);
    parameters.addParameter(STR16("Mute Chnnel 6"), STR16("status"), 1, 0, Vst::ParameterInfo::kCanAutomate, km6);
    parameters.addParameter(STR16("Mute Chnnel 7"), STR16("status"), 1, 0, Vst::ParameterInfo::kCanAutomate, km7);
    parameters.addParameter(STR16("Mute Chnnel 8"), STR16("status"), 1, 0, Vst::ParameterInfo::kCanAutomate, km8);

    parameters.addParameter(STR16("Pass Throught"), STR16("status"), 1, 0, Vst::ParameterInfo::kCanAutomate, kpasst);

    parameters.addParameter(STR16("Sync"), STR16("status"), 1, 0, Vst::ParameterInfo::kIsHidden, ksync);

    parameters.addParameter(STR16("Peak channel 1"), STR16("Volts"), 0, 0, Vst::ParameterInfo::kIsHidden, kp1);
    parameters.addParameter(STR16("Peak channel 2"), STR16("Volts"), 0, 0, Vst::ParameterInfo::kIsHidden, kp2);
    parameters.addParameter(STR16("Peak channel 3"), STR16("Volts"), 0, 0, Vst::ParameterInfo::kIsHidden, kp3);
    parameters.addParameter(STR16("Peak channel 4"), STR16("Volts"), 0, 0, Vst::ParameterInfo::kIsHidden, kp4);
    parameters.addParameter(STR16("Peak channel 5"), STR16("Volts"), 0, 0, Vst::ParameterInfo::kIsHidden, kp5);
    parameters.addParameter(STR16("Peak channel 6"), STR16("Volts"), 0, 0, Vst::ParameterInfo::kIsHidden, kp6);
    parameters.addParameter(STR16("Peak channel 7"), STR16("Volts"), 0, 0, Vst::ParameterInfo::kIsHidden, kp7);
    parameters.addParameter(STR16("Peak channel 8"), STR16("Volts"), 0, 0, Vst::ParameterInfo::kIsHidden, kp8);


    Vst::StringListParameter* stringListParam = new Vst::StringListParameter(
        STR16("networkinterface"),
        kParamNetworkInterfaces   // Parameter ID
    );

    struct ifaddrs *ifap, *ifa;
    int i=0;
    char device_display[256];
    uint8_t mac_addr[6]={0};
    char friendly_name[256];
    
    // Ottieni la lista delle interfacce di rete disponibili
    if (getifaddrs(&ifap) != 0) {
        perror("Errore in getifaddrs");
        freeifaddrs(ifap);
        freeifaddrs(ifa);
    }else{
        for (ifa = ifap; ifa != NULL; ifa = ifa->ifa_next) {
            if (ifa->ifa_name && (strncmp(ifa->ifa_name, "en", 2) == 0) && ifa->ifa_addr->sa_family == AF_LINK ) {
                get_interface_information(ifa->ifa_name,friendly_name,mac_addr);
                
                snprintf(device_display,256, "%s (%02X:%02X:%02X:%02X:%02X:%02X)",friendly_name,
                         mac_addr[0], mac_addr[1], mac_addr[2],mac_addr[3], mac_addr[4], mac_addr[5]);
                
                // - il nome del dispositivo in UTF-16
                std::u16string u16DeviceName = ConvertToUTF16(device_display);
                
                // Aggiungi la stringa al parametro
                stringListParam->appendString(u16DeviceName.c_str());
                if (i == 10) {
                    break;
                }
                i++;
            }
        }
        freeifaddrs(ifap);
        freeifaddrs(ifa);
    }
            
    // Riempie la lista con stringhe vuote se ci sono meno di 10 dispositivi
    while (i < 10) {
        stringListParam->appendString(STR16(""));
        i++;
    }
    
    parameters.addParameter(stringListParam);
    
	return result;
}

//------------------------------------------------------------------------
tresult PLUGIN_API ETH8DACV2Controller::terminate ()
{
	// Here the Plug-in will be de-instantiated, last possibility to remove some memory!

	//---do not forget to call parent ------
	return EditControllerEx1::terminate ();
}

//------------------------------------------------------------------------
tresult PLUGIN_API ETH8DACV2Controller::setComponentState (IBStream* state)
{
	// Here you get the state of the component (Processor part)
	if (!state)
		return kResultFalse;

    IBStreamer streamer(state, kLittleEndian);

    float fval;
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    setParamNormalized(kBypass, fval);

    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    setParamNormalized(kc, fval);

    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    setParamNormalized(ksn, fval);

    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    setParamNormalized(kg1, fval);
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    setParamNormalized(kg2, fval);
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    setParamNormalized(kg3, fval);
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    setParamNormalized(kg4, fval);
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    setParamNormalized(kg5, fval);
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    setParamNormalized(kg6, fval);
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    setParamNormalized(kg7, fval);
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    setParamNormalized(kg8, fval);
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    setParamNormalized(km1, fval);
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    setParamNormalized(km2, fval);
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    setParamNormalized(km3, fval);
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    setParamNormalized(km4, fval);
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    setParamNormalized(km5, fval);
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    setParamNormalized(km6, fval);
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    setParamNormalized(km7, fval);
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    setParamNormalized(km8, fval);
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    setParamNormalized(kpasst, fval);
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    setParamNormalized(kParamNetworkInterfaces, fval);

    
	return kResultOk;
}

//------------------------------------------------------------------------
tresult PLUGIN_API ETH8DACV2Controller::setState (IBStream* state)
{
	// Here you get the state of the controller

	return kResultTrue;
}

//------------------------------------------------------------------------
tresult PLUGIN_API ETH8DACV2Controller::getState (IBStream* state)
{
	// Here you are asked to deliver the state of the controller (if needed)
	// Note: the real state of your plug-in is saved in the processor

	return kResultTrue;
}

//------------------------------------------------------------------------
IPlugView* PLUGIN_API ETH8DACV2Controller::createView (FIDString name)
{
	// Here the Host wants to open your editor (if you have one)
	if (FIDStringsEqual (name, Vst::ViewType::kEditor))
	{
		// create your editor here and return a IPlugView ptr of it
		auto* view = new VSTGUI::VST3Editor (this, "view", "editor.uidesc");
		return view;
	}
	return nullptr;
}

//------------------------------------------------------------------------
} // namespace MyCompanyName
