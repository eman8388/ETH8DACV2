//------------------------------------------------------------------------
// Copyright(c) 2025 eugeniomancini.
//------------------------------------------------------------------------

#include "processor.h"
#include "cids.h"

#include "base/source/fstreamer.h"
#include "pluginterfaces/vst/ivstparameterchanges.h"

using namespace Steinberg;

namespace MyCompanyName {
//------------------------------------------------------------------------
// ETH8DACV2Processor
//------------------------------------------------------------------------
ETH8DACV2Processor::ETH8DACV2Processor ()
{
	//--- set the wanted controller for our processor
	setControllerClass (kETH8DACV2ControllerUID);
}

//------------------------------------------------------------------------
ETH8DACV2Processor::~ETH8DACV2Processor ()
{}

//------------------------------------------------------------------------
tresult PLUGIN_API ETH8DACV2Processor::initialize (FUnknown* context)
{
	// Here the Plug-in will be instantiated
	
	//---always initialize the parent-------
	tresult result = AudioEffect::initialize (context);
	// if everything Ok, continue
	if (result != kResultOk)
	{
		return result;
	}

    //--- create Audio IO ------
    addAudioInput(STR16("In 1"), Steinberg::Vst::SpeakerArr::kStereo);
    addAudioInput(STR16("In 2"), Steinberg::Vst::SpeakerArr::kStereo);
    addAudioInput(STR16("In 3"), Steinberg::Vst::SpeakerArr::kStereo);
    addAudioInput(STR16("In 4"), Steinberg::Vst::SpeakerArr::kStereo);


    addAudioOutput(STR16("Out 1"), Steinberg::Vst::SpeakerArr::kStereo);
    addAudioOutput(STR16("Out 2"), Steinberg::Vst::SpeakerArr::kStereo);
    addAudioOutput(STR16("Out 3"), Steinberg::Vst::SpeakerArr::kStereo);
    addAudioOutput(STR16("Out 4"), Steinberg::Vst::SpeakerArr::kStereo);

	return kResultOk;
}

//------------------------------------------------------------------------
tresult PLUGIN_API ETH8DACV2Processor::terminate ()
{
	// Here the Plug-in will be de-instantiated, last possibility to remove some memory!
    ETHlink_stop(ethlink);
	//---do not forget to call parent ------
	return AudioEffect::terminate ();
}

//------------------------------------------------------------------------
tresult PLUGIN_API ETH8DACV2Processor::setActive (TBool state)
{
	//--- called when the Plug-in is enable/disable (On/Off) -----
	return AudioEffect::setActive (state);
}

//------------------------------------------------------------------------
tresult PLUGIN_API ETH8DACV2Processor::process (Vst::ProcessData& data)
{
    in1 = data.inputs[0].channelBuffers32[0];
    in2 = data.inputs[0].channelBuffers32[1];
    in3 = data.inputs[1].channelBuffers32[0];
    in4 = data.inputs[1].channelBuffers32[1];
    in5 = data.inputs[2].channelBuffers32[0];
    in6 = data.inputs[2].channelBuffers32[1];
    in7 = data.inputs[3].channelBuffers32[0];
    in8 = data.inputs[3].channelBuffers32[1];

    out1 = data.outputs[0].channelBuffers32[0];
    out2 = data.outputs[0].channelBuffers32[1];
    out3 = data.outputs[1].channelBuffers32[0];
    out4 = data.outputs[1].channelBuffers32[1];
    out5 = data.outputs[2].channelBuffers32[0];
    out6 = data.outputs[2].channelBuffers32[1];
    out7 = data.outputs[3].channelBuffers32[0];
    out8 = data.outputs[3].channelBuffers32[1];
    
    //--- First : Read inputs parameter changes-----------
    auto* outParamChanges = data.outputParameterChanges;
    if (data.inputParameterChanges)
    {
        int32 numParamsChanged = data.inputParameterChanges->getParameterCount();
        for (int32 index = 0; index < numParamsChanged; index++)
        {
            if (auto* paramQueue = data.inputParameterChanges->getParameterData(index))
            {
                Vst::ParamValue value;
                int32 sampleOffset;
                int32 numPoints = paramQueue->getPointCount();
                paramQueue->getPoint(numPoints - 1, sampleOffset, value);
                switch (paramQueue->getParameterId())
                {
                    case kBypass:
                        bypass = (float)value;
                        if (bypass) {
                            c = 0;
                        }
                        break;
                    case kc:
                        c = (float)value;
                        if (c) {
                            //ethlink = ETHlink_stop(ethlink);
                            
                            t1 = 0;
                            t2 = 0;
                            printf("\n");
                            
                            ethlink = ETHlink_start(interface_index,sn,data.numSamples/DEVICE_FRAME_PER_BUFFER,(data.numSamples/DEVICE_FRAME_PER_BUFFER)*QUEUE_MULTIPLIER,processSetup.sampleRate);
                            
                            if(!ethlink){
                                c=0;
                            }
                            
                        }else{
                            ethlink = ETHlink_stop(ethlink);
                        }

                    break;
                case ksn:
                    sn = (float)value * 65535;
                    c = 0;
                    break;
                case kParamNetworkInterfaces:
                    interface_index = (float)(value) * 10;
                    c = 0;
                    break;
                case kg1:
                    g1 = (float)value * 80;
                    break;
                case kg2:
                    g2 = (float)value * 80;
                    break;
                case kg3:
                    g3 = (float)value * 80;
                    break;
                case kg4:
                    g4 = (float)value * 80;
                    break;
                case kg5:
                    g5 = (float)value * 80;
                    break;
                case kg6:
                    g6 = (float)value * 80;
                    break;
                case kg7:
                    g7 = (float)value * 80;
                    break;
                case kg8:
                    g8 = (float)value * 80;
                    break;
                case km1:
                    m1 = (bool)value;
                    break;
                case km2:
                    m2 = (bool)value;
                    break;
                case km3:
                    m3 = (bool)value;
                    break;
                case km4:
                    m4 = (bool)value;
                    break;
                case km5:
                    m5 = (bool)value;
                    break;
                case km6:
                    m6 = (bool)value;
                    break;
                case km7:
                    m7 = (bool)value;
                    break;
                case km8:
                    m8 = (bool)value;
                    break;
                case kpasst:
                    pass = (bool)value;
                    break;
                }
            }
            if(c){
                //packet building heder
                ethlink->send_packet[14 + 7] = FSc;
                ethlink->send_packet[14 + 8] = SNc;
                if (m1) { ethlink->send_packet[14 + 9] = (uint8_t)255; }
                else { ethlink->send_packet[14 + 9] = (uint8_t)g1; }
                if (m2) { ethlink->send_packet[14 + 10] = (uint8_t)255; }
                else { ethlink->send_packet[14 + 10] = (uint8_t)g2; }
                if (m3) { ethlink->send_packet[14 + 11] = (uint8_t)255; }
                else { ethlink->send_packet[14 + 11] = (uint8_t)g3; }
                if (m4) { ethlink->send_packet[14 + 12] = (uint8_t)255; }
                else { ethlink->send_packet[14 + 12] = (uint8_t)g4; }
                if (m5) { ethlink->send_packet[14 + 13] = (uint8_t)255; }
                else { ethlink->send_packet[14 + 13] = (uint8_t)g5; }
                if (m6) { ethlink->send_packet[14 + 14] = (uint8_t)255; }
                else { ethlink->send_packet[14 + 14] = (uint8_t)g6; }
                if (m7) { ethlink->send_packet[14 + 15] = (uint8_t)255; }
                else { ethlink->send_packet[14 + 15] = (uint8_t)g7; }
                if (m8) { ethlink->send_packet[14 + 16] = (uint8_t)255; }
                else { ethlink->send_packet[14 + 16] = (uint8_t)g8; }
            }
        }
    }

    if (FS != processSetup.sampleRate) {
        FS = (uint32_t)processSetup.sampleRate;
        if(FS==44100){
            FSc=0;
        }else{
            if(FS==48000){
                FSc=1;
            }else{
                if(FS==88200){
                    FSc=2;
                }else{
                    if(FS==96000){
                        FSc=3;
                    }else{
                        if (c) {
                            printf("Sample frequency not supported!\n");
                            FS = 0;
                        }
                    }
                }
            }
        }
        c=0;
    }
    
    if (sampleN != data.numSamples) {
        sampleN = data.numSamples;
        if (sampleN !=8 && sampleN!= 16 && sampleN != 32 && sampleN != 64 && sampleN != 128 && sampleN != 256 && sampleN != 512 && sampleN!= 1024) {
            if (c) {
                printf("Sample per buffer not supported!\n");
            }
            sampleN = 0;
        }else{
            SNc=sampleN/8;
            printf("SNc = %d\n",SNc);
        }
        c=0;
    }
    
    if(c){
        for (int i = 0; i < data.numSamples; i++) {
            obuff[(i * 8)] = (int32_t)(((float)in1[i]) * 2147483648.0f);
            obuff[(i * 8) + 1] = (int32_t)(((float)in2[i]) * 2147483648.0f);
            obuff[(i * 8) + 2] = (int32_t)(((float)in3[i]) * 2147483648.0f);
            obuff[(i * 8) + 3] = (int32_t)(((float)in4[i]) * 2147483648.0f);
            obuff[(i * 8) + 4] = (int32_t)(((float)in5[i]) * 2147483648.0f);
            obuff[(i * 8) + 5] = (int32_t)(((float)in6[i]) * 2147483648.0f);
            obuff[(i * 8) + 6] = (int32_t)(((float)in7[i]) * 2147483648.0f);
            obuff[(i * 8) + 7] = (int32_t)(((float)in8[i]) * 2147483648.0f);
            if (max1 < fabs(in1[i])) {
                max1 = fabs(in1[i]);
            }
            if (max2 < fabs(in2[i])) {
                max2 = fabs(in2[i]);
            }
            if (max3 < fabs(in3[i])) {
                max3 = fabs(in3[i]);
            }
            if (max4 < fabs(in4[i])) {
                max4 = fabs(in4[i]);
            }
            if (max5 < fabs(in5[i])) {
                max5 = fabs(in5[i]);
            }
            if (max6 < fabs(in6[i])) {
                max6 = fabs(in6[i]);
            }
            if (max7 < fabs(in7[i])) {
                max7 = fabs(in7[i]);
            }
            if (max8 < fabs(in8[i])) {
                max8 = fabs(in8[i]);
            }
        }
        ETHlink_send(ethlink, obuff);
    }else{
        s=0;
    }
    
    //passtroght
    if (pass) {
        for (int32 i = 0; i < data.numSamples; i++)
        {
            out1[i] = in1[i];
            out2[i] = in2[i];
            out3[i] = in3[i];
            out4[i] = in4[i];
            out5[i] = in5[i];
            out6[i] = in6[i];
            out7[i] = in7[i];
            out8[i] = in8[i];
        }
    }
    else {
        memset(out1, 0, data.numSamples * 4);
        memset(out2, 0, data.numSamples * 4);
        memset(out3, 0, data.numSamples * 4);
        memset(out4, 0, data.numSamples * 4);
        memset(out5, 0, data.numSamples * 4);
        memset(out6, 0, data.numSamples * 4);
        memset(out7, 0, data.numSamples * 4);
        memset(out8, 0, data.numSamples * 4);
    }
    
    //viewupdate
    t1 += data.numSamples / processSetup.sampleRate;
    t2 += data.numSamples / processSetup.sampleRate;
    

    if (c && t2 > 1.) {
        t2 = 0;
        if (ETHlink_receive(ethlink, receive_buffer) && !memcmp(ethlink->send_packet+14, receive_buffer + 14, 50)) {
            s = 1;
        }else {
            s = 0;
        }
    }
    
    //parameter viewupdate
    if (t1 > INTERFACE_REFRESH_VIEW) {
        t1 = 0;
        int32 index;
        auto* paramQueue = outParamChanges->addParameterData(kc, index);
        paramQueue->addPoint(0, c, index);
        paramQueue = outParamChanges->addParameterData(ksync, index);
        paramQueue->addPoint(0, s, index);
        paramQueue = outParamChanges->addParameterData(kp1, index);
        paramQueue->addPoint(0, max1 * !m1 * pow(10, ((float)g1-56.)/20.) , index);
        paramQueue = outParamChanges->addParameterData(kp2, index);
        paramQueue->addPoint(0, max2 * !m2 * pow(10, ((float)g2-56.)/20.), index);
        paramQueue = outParamChanges->addParameterData(kp3, index);
        paramQueue->addPoint(0, max3 * !m3 * pow(10, ((float)g1-56.)/20.), index);
        paramQueue = outParamChanges->addParameterData(kp4, index);
        paramQueue->addPoint(0, max4 * !m4 * pow(10, ((float)g4-56.)/20.), index);
        paramQueue = outParamChanges->addParameterData(kp5, index);
        paramQueue->addPoint(0, max5 * !m5 * pow(10, ((float)g5-56.)/20.), index);
        paramQueue = outParamChanges->addParameterData(kp6, index);
        paramQueue->addPoint(0, max6 * !m6 * pow(10, ((float)g6-56.)/20.), index);
        paramQueue = outParamChanges->addParameterData(kp7, index);
        paramQueue->addPoint(0, max7 * !m7 * pow(10, ((float)g7-56.)/20.), index);
        paramQueue = outParamChanges->addParameterData(kp8, index);
        paramQueue->addPoint(0, max8 * !m8 * pow(10, ((float)g8-56.)/20.), index);

        //reset vumeter
        max1 = 0;
        max2 = 0;
        max3 = 0;
        max4 = 0;
        max5 = 0;
        max6 = 0;
        max7 = 0;
        max8 = 0;
    }
    
	return kResultOk;
}

//------------------------------------------------------------------------
tresult PLUGIN_API ETH8DACV2Processor::setupProcessing (Vst::ProcessSetup& newSetup)
{
	//--- called before any processing ----
	return AudioEffect::setupProcessing (newSetup);
}
//correct the bus arrangemt
tresult PLUGIN_API ETH8DACV2Processor::setBusArrangements(Steinberg::Vst::SpeakerArrangement* inputs, Steinberg::int32 numIns,
    Steinberg::Vst::SpeakerArrangement* outputs, Steinberg::int32 numOuts)
{
    removeAudioBusses();
    addAudioInput(STR16("In 1"), Steinberg::Vst::SpeakerArr::kStereo);
    addAudioInput(STR16("In 2"), Steinberg::Vst::SpeakerArr::kStereo);
    addAudioInput(STR16("In 3"), Steinberg::Vst::SpeakerArr::kStereo);
    addAudioInput(STR16("In 4"), Steinberg::Vst::SpeakerArr::kStereo);


    addAudioOutput(STR16("Out 1"), Steinberg::Vst::SpeakerArr::kStereo);
    addAudioOutput(STR16("Out 2"), Steinberg::Vst::SpeakerArr::kStereo);
    addAudioOutput(STR16("Out 3"), Steinberg::Vst::SpeakerArr::kStereo);
    addAudioOutput(STR16("Out 4"), Steinberg::Vst::SpeakerArr::kStereo);

    return kResultFalse;
}
//------------------------------------------------------------------------
tresult PLUGIN_API ETH8DACV2Processor::canProcessSampleSize (int32 symbolicSampleSize)
{
	// by default kSample32 is supported
	if (symbolicSampleSize == Vst::kSample32)
		return kResultTrue;

	// disable the following comment if your processing support kSample64
	/* if (symbolicSampleSize == Vst::kSample64)
		return kResultTrue; */

	return kResultFalse;
}

//------------------------------------------------------------------------
tresult PLUGIN_API ETH8DACV2Processor::setState (IBStream* state)
{
	// called when we load a preset, the model has to be reloaded
	IBStreamer streamer (state, kLittleEndian);
    float fval;
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    bypass = (bool)fval;
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    c = (bool)fval;
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    sn = fval * 65535;
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    g1 = fval * 80;
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    g2 = fval * 80;
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    g3 = fval * 80;
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    g4 = fval * 80;
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    g5 = fval * 80;
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    g6 = fval * 80;
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    g7 = fval * 80;
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    g8 = fval * 80;
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    m1 = (bool)fval;
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    m2 = (bool)fval;
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    m3 = (bool)fval;
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    m4 = (bool)fval;
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    m5 = (bool)fval;
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    m6 = (bool)fval;
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    m7 = (bool)fval;
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    m8 = (bool)fval;
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    pass = (bool)fval;
    if (streamer.readFloat(fval) == false)
    {
        return kResultFalse;
    }
    interface_index = fval * 10;

    c = 0;
	return kResultOk;
}

//------------------------------------------------------------------------
tresult PLUGIN_API ETH8DACV2Processor::getState (IBStream* state)
{
	// here we need to save the model
	IBStreamer streamer (state, kLittleEndian);

    streamer.writeFloat((float)bypass);
    streamer.writeFloat((float)c);
    streamer.writeFloat((float)sn / 65535);
    streamer.writeFloat((float)g1 / 80);
    streamer.writeFloat((float)g2 / 80);
    streamer.writeFloat((float)g3 / 80);
    streamer.writeFloat((float)g4 / 80);
    streamer.writeFloat((float)g5 / 80);
    streamer.writeFloat((float)g6 / 80);
    streamer.writeFloat((float)g7 / 80);
    streamer.writeFloat((float)g8 / 80);
    streamer.writeFloat((float)m1);
    streamer.writeFloat((float)m2);
    streamer.writeFloat((float)m3);
    streamer.writeFloat((float)m4);
    streamer.writeFloat((float)m5);
    streamer.writeFloat((float)m6);
    streamer.writeFloat((float)m7);
    streamer.writeFloat((float)m8);
    streamer.writeFloat((float)pass);
    streamer.writeFloat((float)interface_index / 10);

	return kResultOk;
}

//------------------------------------------------------------------------
} // namespace MyCompanyName
