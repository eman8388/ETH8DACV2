//------------------------------------------------------------------------
// Copyright(c) 2025 eugeniomancini.
//------------------------------------------------------------------------

#pragma once

#include "pluginterfaces/base/funknown.h"
#include "pluginterfaces/vst/vsttypes.h"

namespace MyCompanyName {
//------------------------------------------------------------------------
static const Steinberg::FUID kETH8DACV2ProcessorUID (0x63B9AF1A, 0xB3F656AE, 0xB2B9E51A, 0xD66AD9F9);
static const Steinberg::FUID kETH8DACV2ControllerUID (0xDABAA212, 0x29A451B4, 0x9922CA0E, 0xB954F525);

#define ETH8DACV2VST3Category "Fx"

//------------------------------------------------------------------------
} // namespace MyCompanyName
