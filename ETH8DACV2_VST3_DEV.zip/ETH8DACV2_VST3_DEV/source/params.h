//
//  params.h
//  ETH8DACV2
//
//  Created by eugenio mancini on 20/01/25.
//

#pragma once
enum
{
    kBypass = 0,
    kc,
    ksn,
    kg1,
    kg2,
    kg3,
    kg4,
    kg5,
    kg6,
    kg7,
    kg8,
    km1,
    km2,
    km3,
    km4,
    km5,
    km6,
    km7,
    km8,
    kpasst,
    ksync,
    kp1,
    kp2,
    kp3,
    kp4,
    kp5,
    kp6,
    kp7,
    kp8,
    kParamNetworkInterfaces,
};
